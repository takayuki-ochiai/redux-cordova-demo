import React from 'react'
import { render } from 'react-dom'

// Redux 用ライブラリ
import { Provider } from 'react-redux'
import { createStore, applyMiddleware } from 'redux'
import thunkMiddleware from 'redux-thunk'
import createLogger from 'redux-logger'

// ルーティング用ライブラリ
import { Router, Route, IndexRoute, hashHistory } from 'react-router'
import { syncHistoryWithStore } from 'react-router-redux'

// Material UI 用ライブラリ
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin'

import todoApp from './reducers'
import TransitionCtrl from './containers/TransitionCtrl'
import App from './components/App'
import About from './components/About'
import MotionPractice from './components/MotionPractice'

// Material UIを使用する場合、ReactがV1.0になるまでは必要らしい
injectTapEventPlugin()


const Transition = props => (
  <TransitionCtrl {...props} />
);

const loggerMiddleware = createLogger();

let store = createStore(
  todoApp,
  applyMiddleware(
    thunkMiddleware, // lets us dispatch() functions
    loggerMiddleware // neat middleware that logs actions
  )
);

// immutable.jsとreact-router-reduxを併用する場合はselectLocationStateオプションに下記をセットする必要がある
// redux-immutableを使っていないのでstate.get('routing')ではない
const history = syncHistoryWithStore(hashHistory, store, {
  selectLocationState: state => state.routing.toJS()
});

render(
  <MuiThemeProvider muiTheme={getMuiTheme()}>
    <Provider store={store}>
      <Router history={history}>
        <Route path="/" component={Transition}>
          <IndexRoute component={App} />
          <Route path="/about" component={About} />
          <Route path="/motion-practice" component={MotionPractice} />
        </Route>
      </Router>
    </Provider>
  </MuiThemeProvider>,
  document.getElementById('app')
)
