const React = require("react");

class HelloReact extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (<div>はげほげ</div>);
  }
}

module.exports = HelloReact;
